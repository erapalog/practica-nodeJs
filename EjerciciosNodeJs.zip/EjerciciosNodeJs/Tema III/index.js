var http = require('http')


const hour = new Date().getHours();
const arrayNombre = ['Ana', 'Juan', 'pedro'];

const arrayPersona = [{
        nombre: 'Ana',
        edad: 25
    },
    {
        nombre: 'Juan',
        edad: 16
    }
]

if (hour > 12) {
    console.log("Es mas de medio dia")
} else {
    console.log('Es de manana')
}

arrayNombre.forEach(item => {
    console.info(item)
})


arrayPersona.forEach(item=>{
    console.log(item.nombre +item.edad);
})

var app = function (request, response) {

    response.end("Curso de Node Js")
}

http.createServer(app).listen(3000);