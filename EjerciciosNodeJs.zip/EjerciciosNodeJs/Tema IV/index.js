let fs = require('fs')

fs.readFile('prueba.txt', 'utf-8', (err, data) => {
    if (err) {
        console.log("Ocurrio un error: ", err)
    } else {
        console.log(data)

        console.log(convertirArray(data))

    }
})

function convertirArray(text) {
    return text.split('.')
}