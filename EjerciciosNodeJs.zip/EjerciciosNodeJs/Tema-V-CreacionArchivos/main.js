const fs = require('fs')


function escribirArchivo(error, data) {
    if (error) {
        console.log('Ocurrio un error')
    } else {
        console.log("Archivo creado")
    }

}

function leerArchivo(error, data) {
    if (error) {
        console.log('Ocurrio un error')
    } else {
        console.log(data.toString())
    }
}

//haciendo uso de funcines anonimas y operacion lamba
/*fs.writeFile('./test.txt', 'Bienvenidos a Node Js', (error, data) => {

    if (error) {
        console.log('Ocurrio un error ' + error)
    } else {
        console.log('Archivo creado')
    }
})*/

//llamada a funciones con callback
fs.writeFile('./test2.txt', 'Bienvenidos a Node Js con llamados callback', escribirArchivo)

fs.readFile('./test2.txt', leerArchivo)

console.log('fin de ejecucion')