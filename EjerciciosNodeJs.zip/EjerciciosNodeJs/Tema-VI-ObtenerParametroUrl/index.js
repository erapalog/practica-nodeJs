const http = require('http');

//modulo para obtener informacion de mis paginas
const url = require('url');

const server = http.createServer((request, response) => {

    //parseando o convirtiendo a un tipo de objeto
    let objetoUrl = url.parse(request.url)

    //direccion completa del sitio
    console.log("Direccion completa => " + objetoUrl.path);

    //direccion sin parametros
    console.log('Nombre sin parametros =>' + objetoUrl.pathname);

    //accedienco a los parametros
    console.log('parametros => ' + objetoUrl.query)

    let parametroUrl;
    if (objetoUrl.query != null)
        parametroUrl = objetoUrl.query.toString().split('=')
	

    console.log("Arreglo de parametros => " +parametroUrl)

    response.writeHead(200, {
        'Content-type': 'text/html'
    });

    response.write('<!doctype html><body>Comunicacion Existosa</body></html>');

    response.end();
})

server.listen(3000)