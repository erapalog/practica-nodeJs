const http = require('http')
const url = require('url')
const fs = require('fs')


const server = http.createServer((request, response) => {
    let urlServerOrginal = url.parse(request.url);

    // pathname lo que devuelve la porcion del sitio sin tomar en cuenta el host
    ///index.html
    let urlServer = 'public' + urlServerOrginal.pathname;

    //http://localhost:3001/
    //http://localhost:3001


    if (urlServer == 'public/')
        urlServer = 'public/index.html'
    else {

        //validar si un archivo existe dentro de un directorio
        fs.stat(urlServer, error => {
            if (!error) {
                fs.readFile(urlServer, (error, data) => {
                    if (error) {
                        response.writeHead(500, {
                            'Content-Type': 'text/plan'
                        })
                        response.write('Ocurrio un error en el servidor');
                        response.end();
                    } else {

                        var response2;
                        var etiqueta;
                        for(let x=0;x<10;x++){
                            etiqueta+='<p>'+x+'</p>'
                        }

                        response2=data+etiqueta
                        
                        response.writeHead(200, {
                            'Content-Type': 'text/html'
                        })
                        response.write(response2);
                        response.end()
                    }
                })

            } else {

                response.writeHead(404, {
                    'Content-Type': 'text/plan'
                })
                response.write('Recurso solicitado no existe');
                response.end();
            }

        })

    }
})

server.listen(3001)