const http = require('http')


const server = http.createServer((request, response) => {

    //nos permite escribir codigos de respuesta y tipo de contenido soportado
    response.writeHead(200, {
        'Content-Type': 'text/html'
    });

    //tipo de informacion a enviar en este caso html
    response.write('<! doctype html><body> <p style="color:blue; font-size:25px"> Hola Mundo</p></body> </html>');
    response.end();
})

server.listen(3000)