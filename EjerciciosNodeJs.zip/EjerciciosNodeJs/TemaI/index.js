var http = require('http')
var operacionesBasicas = require('./modulos_dev/utils')



var server = http.createServer(function (request, response) {
    response.end("El resultado de la operacion es: "+operacionesBasicas.multiplicar(5, 5));
});

server.listen(3001, function () {
    console.log("Aplicacion ejecutando en el puerto 3001")
});