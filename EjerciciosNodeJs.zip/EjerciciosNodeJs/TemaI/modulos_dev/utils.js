//clase que nos realice las operaciones basicas

function suma(a,b){
    return a+b;
}

function restar(a,b){
    return a-b
}

function multiplicar(a,b){
    return a*b
}

function dividir(a,b){
    return a/b
}

module.exports={
    suma:suma,
    restar:restar,
    multiplicar:multiplicar,
    dividir:dividir
}
