

var http= require('http')

var colors = require('colors');

var server=http.createServer(function (request,respose){
    respose.end('Bienvenido a node js');
})

server.listen(3000,function(){
   console.log("Escuchando en el puerto 3000" .red)
});

